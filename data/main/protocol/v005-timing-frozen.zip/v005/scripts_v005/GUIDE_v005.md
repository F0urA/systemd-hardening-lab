# Как воспроизвести эксперимент (v005)

Эксперимент выполнен в два этапа: 11.10.2026 (шаги 1–12) и 12.10.2026 (шаги 13–18, дополнение `protocol_review_v005.txt`). Что получилось, какие были отклонения и находки, записано в `results_v005/report_v005.md`.

## Что нужно

- Чистая установка ALT Server 11.1 в виртуальной машине: 4 виртуальных процессора, около 4 ГБ памяти, доступ в интернет к репозиторию пакетов.
- Вход под root.
- Для нагрузочных серий — хост, на котором машина не переезжает между ядрами разного типа и не уходит в режим ожидания. На ноутбуке с гибридным процессором машина была привязана к производительным ядрам (маска задаётся процессу `VBoxSVC`, машина наследует её при запуске).

## Этап 1

Каталоги `scripts_v005` и `stand_v005` копируются на стенд рядом друг с другом, например в `/root/v005`. Все команды выполняются из `scripts_v005`.

| Шаг | Команда | Меняет службы | Результат в `/root/systemd-lab-results` |
|---|---|---|---|
| 1. Сборка стенда | `./setup_stand_v005.sh` | создаёт их | `stand-v005.txt`, `setup-v005.log` |
| 2. Кандидаты | `./make_candidates_v005.sh`, `./make_ablation_v005.sh` | нет | `P6.conf`, `P1r.conf`, `P1c.conf`, `P4s.conf`, `P4n.conf` в каталогах профилей |
| 3. Микропроверки | `./probe_all_v005.sh` | нет | `probe-v005/<дата>` |
| 4. Соответствие модельного процесса реальному | `./context_compare_v005.sh` | да | `context-v005/<дата>` |
| 5. Пилот нагрузки | `NGINX_N=100000 ./benchmark_v005.sh nginx 10 P4` | да | `nginx/benchmark-v005/<дата>` |
| 6. Фиксация протокола | коммит `protocol_v005.txt` и `protocol_load_v005.txt` | — | — |
| 7. Цели нарушителя | `NGINX_PROFILES='P0 P4 P5 P6' ./scenarios_v005.sh` | да | `scenarios-v005/<дата>` |
| 8. Расширенная функциональная проверка | `NGINX_PROFILES='P0 P4 P5 P6' ./functional_ext_v005.sh` | да | `functional-v005/<дата>` |
| 9. Нагрузочные серии | см. ниже | да | `<служба>/benchmark-v005/<дата>` |
| 10. Причина роста затрат | см. ниже | да | `nginx/benchmark-v005/<дата>` |
| 11. Таблица критериев и выбор | см. ниже | нет | `criteria_*.csv`, `selection_*.txt` |
| 12. Лестница профилей | `./ladder_check_v005.sh` | да | `ladder-v005/<дата>` |

Скрипты, меняющие службы, требуют исходного состояния стенда (три службы под сохранённым P4, других drop-in нет) и возвращают его при выходе.

После перезагрузки машины процессы-мишени нужно запустить вручную:

```
for u in labweb labredis labpg root; do systemctl start lab-proc-target@$u; done
```

На этапе 1 сценарии шага 7 выполнялись первой редакцией скрипта: без усиленной проверки G1 и без ячеек уровня процесса (история репозитория, тег `v003`).

### Шаг 5. Условие запуска серий

Серии запускаются, только если коэффициент вариации P0 в пилоте не выше 5 %. В `run.log` значение `CPU_PCT` должно быть выше 90: это признак того, что узкое место — сервер.

### Шаг 9. Нагрузочные серии

```
NGINX_N=100000 ./benchmark_v005.sh nginx 20 P4 P5 P6
REDIS_THREADS=3 REDIS_N=3000000 ./benchmark_v005.sh redis 20
PG_T=60 ./benchmark_v005.sh postgresql 10
```

В конце каждой серии печатается проверка для каждого кандидата: `PRIMARY_NONINFERIORITY_95` и `CPU_PER_OP_ONE_SIDED_95_UPPER_INCREASE`. Строка `INVALID MEASUREMENTS REPEATED` показывает, сколько измерений повторено из-за пауз виртуальной машины.

### Шаг 10. Причина роста затрат

```
NGINX_N=100000 ./benchmark_v005.sh nginx 20 P4 P4s P4n
python3 ablation_report_v005.py <каталог серии>/results.csv
```

## Этап 2 (дополнение `protocol_review_v005.txt`)

| Шаг | Команда | Меняет службы | Результат |
|---|---|---|---|
| 13. Подготовка стенда, собранного прежней редакцией | `./prepare_stand_v005.sh`, `./make_candidates_v005.sh` | нет | помощники под именами v005; `P1r.conf`, `P1c.conf` |
| 14. Микропроверки | `./probe_all_v005.sh` | нет | `probe-v005/<дата>` |
| 15. Цели нарушителя, все кандидаты | `./scenarios_v005.sh` | да | `scenarios-v005/<дата>` |
| 16. Расширенная функциональная проверка | `./functional_ext_v005.sh nginx` | да | `functional-v005/<дата>` |
| 17. Нагрузочная серия | `NGINX_N=100000 ./benchmark_v005.sh nginx 60 P1 P2 P1r P1c P4` | да | `nginx/benchmark-v005/<дата>` |
| 18. Системные вызовы на операцию | `./syscall_count_v005.sh` | да | `syscalls-v005/<дата>` |

Во время шага 17 на хосте (Windows) работает журнал состояния процессора:

```
powershell -ExecutionPolicy Bypass -File host_activity_v005.ps1 -Out host-activity.csv
```

Время окончания каждого измерения берётся на стенде:

```
cd /root/systemd-lab-results/nginx/benchmark-v005 && stat -c '%Y <серия> %n' <серия>/ab-*-g1.txt
```

## Этап 3 (дополнение `protocol_review2_v005.txt`, рецензия на v004)

Фиксируется коммитом `protocol_review2_v005.txt` и `procedure_v005.txt` **до** запуска. Все шаги, кроме 25, меняют службы и возвращают стенд в исходное состояние при выходе.

| Шаг | Команда | Замечание | Результат |
|---|---|---|---|
| 19. Соответствие модельного процесса реальному для лёгких профилей | `PROFILES='P1 P1r P1c' ./context_compare_v005.sh` | 1 | `context-v005/<дата>` |
| 20. Абляция capabilities P1c | `./cap_ablation_v005.sh`, затем `NGINX_PROFILES='P1r P1c P1cADMIN P1cPTRACE P1cDAC P1cCHROOT' ./scenarios_v005.sh nginx` | 4 | `nginx/profiles/P1c*.conf`, `scenarios-v005/<дата>` |
| 21. Цели нарушителя, независимые G3/G4 и доп. обходы | `./scenarios_v005.sh` | 2, 3, 5 | `scenarios-v005/<дата>` |
| 22. Контракт и миграция P0/P1 → P1c | `./functional_ext_v005.sh nginx` (строки `migrate-*`, `contract.csv`) | 6 | `functional-v005/<дата>` |
| 23. Общая серия Nginx | `NGINX_N=100000 ./benchmark_v005.sh nginx 60 P1c P4 P5 P6` | 12 | `nginx/benchmark-v005/<дата>` |
| 24. Лестница Redis и PostgreSQL под нагрузкой | `make_candidates_v005.sh` (ступени P1, P2, P1d), затем `./benchmark_v005.sh redis 20 P1 P2 P1d P4 P6` и `postgresql 10 ...` | 14 | `redis/`, `postgresql/benchmark-v005/<дата>` |
| 25. Ненасыщенная серия | `NGINX_C=<из пилота> ./benchmark_v005.sh nginx 60 P1c P4` при загрузке 40–70 % | 17 | `nginx/benchmark-v005/<дата>` |
| 26. Третий этап: новая служба | строится на стенде (первая из memcached/unbound/mosquitto), см. `procedure_v005.txt` | 8 | `<служба>/...` |

Прямые парные контрасты между защищающими профилями в общей серии:

```
python3 robustness_v005.py --pairs P1c-P5,P1c-P6 R1=$R/nginx/benchmark-v005/<серия 23>/results.csv
```

## Таблица критериев и выбор

Уровень решения с поправкой на число кандидатов и плановый добор (замечания 9, 10):

```
R=/root/systemd-lab-results
python3 build_criteria_v005.py --probe $R/probe-v005/<дата> --scenarios $R/scenarios-v005/<дата> \
  --bench nginx=$R/nginx/benchmark-v005/<общая серия>:P1c,P4,P5,P6 \
  --bench nginx=$R/nginx/benchmark-v005/<серия P1/P2/P1r>:P1,P2,P1r \
  --bench redis=$R/redis/benchmark-v005/<дата> \
  --bench postgresql=$R/postgresql/benchmark-v005/<дата> \
  --level 0.05 --family nginx=4 --family redis=4 --family postgresql=4 --looks 2 --out $R/criteria.csv
# цель-добор серии кандидата с исходом NEEDS_MORE_DATA: повторить серию и объединить
#   --bench nginx=<серия1>+<серия2>:<кандидат>
python3 select_profile_v005.py $R/criteria.csv --budgets 2,5,10,15 \
  --require nginx=G2-read-app-secret   # пример обязательной цели (замечание 5)
python3 order_sensitivity_v005.py $R/criteria.csv --budgets 2,5,10,15   # замечание 16
```

Источник границ для каждого кандидата задаётся в командной строке.

## Дополнительные расчёты

- `robustness_v005.py` — три статуса кандидата, граница с поправкой Бонферрони, бутстреп-границы, наименьший порог допуска; `--pairs A-B` — прямые парные контрасты между защищающими профилями одной серии.
- `pool_series_v005.py` — объединяет две серии в один файл с последовательными номерами блоков (расчёт по 40 блокам).
- `freq_adjust_v005.py` — расчёт с нормировкой на частоту процессора хоста; нужен журнал состояния хоста и время окончания измерений. Для серий 11.10.2026 разведочный, для серии этапа 2 заявлен в протоколе заранее.

## Нумерация

Все файлы и каталоги имеют один номер версии — v005. Соответствие имён, встречающихся в журналах, нынешним именам приведено в начале `results_v005/report_v005.md`; прежние редакции скриптов доступны в истории репозитория (теги `v003` и `v004`).
