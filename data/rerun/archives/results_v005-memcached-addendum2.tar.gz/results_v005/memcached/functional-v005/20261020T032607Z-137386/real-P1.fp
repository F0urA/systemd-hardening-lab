Uid: 979 979 979 979
Gid: 958 958 958 958
Groups: 958
CapInh: 0000000000000000
CapPrm: 0000000000000000
CapEff: 0000000000000000
CapBnd: 000001ffffffffff
CapAmb: 0000000000000000
NoNewPrivs: 1
Seccomp: 0
Seccomp_filters: 0
ns_cgroup: cgroup:[4026531835]
ns_ipc: ipc:[4026531839]
ns_mnt: mnt:[4026532250]
ns_net: net:[4026531840]
ns_pid: pid:[4026531836]
ns_user: user:[4026531837]
ns_uts: uts:[4026531838]
